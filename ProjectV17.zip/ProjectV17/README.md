#### How to setup ID_Generator

Prerequisites for this project
-------------------------------
Installation of ID Generator requires following permissions and resources:
1) Public & Private Subnets
2) Security Group
3) Virtual Private Cloud
4) NAT Gateway
5) RDS Aurora Serverless
6) Lambda Functions

=> First download project from github and extract it. Open project in any editor(VS Code, Notepad++ etc).
=> Select secrets.auto.tfvars file and change the Account Id and Region according to your AWS Account Id and Region.
=> Download and Install aws-cli tool and configure it in your system.
=> Open command prompt (cmd) and navigate to ID Generator directory.
=> Run "terraform init" command to initialize terraform in the project. 
=> Run "terraform plan" command to plan the recources.
=> Run "terraform apply" command to create the recources in aws.

=> After "terraform apply" command completes, copy the Lambda function url and use it to call GET method through browser or Postman.
=> In the POST method of Lambda function, send parameters in JSON format.

   Details of REST API parameters:
    AppName: This is the application name e.g. GuideWire, Surety, Arden and APS.
    Type: This is Id Type e.g. Account, Policy and Quote.
    User: This contains user details e.g. email address or any other system info

    Example:
      curl -H "Content-Type: application/json" -X POST -d "{\"AppName\":\"Surety\",\"Type\":\"Account\",\"User\":\"johndoe12345@gmail.com\"}" "<Lambda function`s url>"

=> To get data from database based on the Id, send a parametrized GET request. Url of the request looks like below:
      https://fogykt2ixwomumpk4en76d6roq0jwlrq.lambda-url.us-east-1.on.aws?Id=4000002&AppName=GuideWire&Type=Policy 
=> It returns detail of the Id for the AppName and Type provided (if it exists)


=> To get last record of any application from the database, send a parametrized GET request. Url of the request looks like below:
      https://fogykt2ixwomumpk4en76d6roq0jwlrq.lambda-url.us-east-1.on.aws?AppName=GuideWire&Type=Policy
=> It returns detail of last Id generated for the provided AppName and Type.


=> Assign new range for the applications as follow:
=> Send PUT request with the following json parameters:
   {
    "StartRange": "80000001",
    "EndRange": "90000000",
    "UserRole": "Admin",
    "Type": "Policy"
   }
=> The above request assigns the new range for all applications.

#### Schema for RDS
Lambda function creates following 2 tables in the RDS database:
1) SequenceRange
2) SequenceAccountIds
3)	SequencePolicyIds


#### Table for SequenceRange

=> Columns in the SequenceRange table are ( Id, StartRange, EndRange, SequenceType and Status ) and this table is used to store the starting point, ending point, sequence type and status for all applications in the table.

#### Table for SequenceAccountIds

=> Columns in the SequenceAccountIds table are ( Id, AppName, Type, Date, Time and User ) and this table is used to generate a new Id for Account and save application name, sequence type of id, current date, time and user information in that table.

#### Table for SequencePolicyIds

=> Columns in the SequencePolicyIds table are ( Id, AppName, Type, Date, Time and User ) and this table is used to generate a new Id for Policy and save application name, sequence type of id, current date, time and user information in that table.


