import json
import sys
import logging
import pymysql
import os
import asyncio

# getting credientials from variable.tf file
REGION = os.environ['AWS_REGION']
rds_host = os.environ['host']
name = os.environ['username']
password = os.environ['password']
db_name = os.environ['database']
myport = 3306 

account_start_range = os.environ['account_start_range']
account_end_range = os.environ['account_end_range']
policy_start_range = os.environ['policy_start_range']
policy_end_range = os.environ['policy_end_range']

logger = logging.getLogger()
logger.setLevel(logging.INFO)
    
# This try block makes a connection with RDS
try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, port=myport)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

async def create_range_table():
    try:
        
        with conn.cursor() as cur:
            # table_name = "SequenceRange"

            query1 = f"CREATE TABLE SequenceRange (Id INT UNSIGNED NOT NULL AUTO_INCREMENT, StartRange int, EndRange int, SequenceType varchar(255), Status varchar(255), PRIMARY KEY (Id))AUTO_INCREMENT = {1}; "
            cur.execute(query1)

            query2 = """INSERT INTO SequenceRange (StartRange, EndRange, SequenceType, Status) values(%s, %s, %s, %s) """
            query_values2 = (account_start_range, account_end_range, 'Account', 'True')
            cur.execute(query2, query_values2)

            query3 = """INSERT INTO SequenceRange (StartRange, EndRange, SequenceType, Status) values(%s, %s, %s, %s) """
            query_values3 = (policy_start_range, policy_end_range, 'Policy', 'True')
            cur.execute(query3, query_values3)
        conn.commit()
        
    except Exception as e:
        logger.error("ERROR: Unexpected error.."+ str(e))

async def create_sequence_account_ids_table():
    try:
        with conn.cursor() as cur:

            query1 = """SELECT * FROM SequenceRange WHERE Status= %s AND SequenceType= %s """
            query_values1 = ('True', 'Account')
            AccountRange = cur.execute(query1, query_values1)
            AccountRange = cur.fetchall()
                        
            for row in AccountRange:
                startId = row[1] # get startId from RDS
            start_autoincr = startId

            query2 = f"CREATE TABLE SequenceAccountIds (Id INT UNSIGNED NOT NULL AUTO_INCREMENT, AppName varchar(255), Type varchar(255), Date varchar(255), Time varchar(255), User varchar(255), PRIMARY KEY (Id))AUTO_INCREMENT = {start_autoincr}; "
            cur.execute(query2)

        conn.commit()
        
    except Exception as e:
        logger.error("ERROR: Unexpected error.."+ str(e)) 

async def create_sequence_policy_ids_table():
    try:
        with conn.cursor() as cur:
            # table_name = "SequencePolicyIds"

            query1 = """ SELECT * FROM SequenceRange WHERE Status= %s AND SequenceType= %s """
            query_values1 = ('True', 'Policy')
            PolicyRange = cur.execute(query1, query_values1)
            PolicyRange = cur.fetchall()
                        
            for row in PolicyRange:
                startId = row[1] # get startId from RDS
            start_autoincr = startId

            query2 = f" CREATE TABLE SequencePolicyIds (Id INT UNSIGNED NOT NULL AUTO_INCREMENT, AppName varchar(255), Type varchar(255), Date varchar(255), Time varchar(255), User varchar(255), PRIMARY KEY (Id))AUTO_INCREMENT = {start_autoincr}; "
            cur.execute(query2)

        conn.commit()
        
    except Exception as e:
        logger.error("ERROR: Unexpected error.."+ str(e))   
 

async def executeMyQuery():
    try:
        
        await create_range_table()
        
        await create_sequence_account_ids_table()

        await create_sequence_policy_ids_table()

    except Exception as e:
        logger.error("ERROR: Unexpected error.."+ str(e))
                   
def lambda_handler(event, context):
    try:
        asyncio.run(executeMyQuery())
        return {"body": "Tables are successfully created"}
    except Exception as e:
        logger.error("ERROR: Unexpected error.."+ str(e))
    return {"body": "Error occurred while creating tables: " + str(e)}  