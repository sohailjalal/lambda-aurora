import json
import sys
import logging
import pymysql
import os
import boto3
from botocore.exceptions import ClientError
import time


REGION = os.environ['AWS_REGION']
rds_host = os.environ['host']
name = os.environ['username']
password = os.environ['password']
db_name = os.environ['database']
myport = 3306   

logger = logging.getLogger()
logger.setLevel(logging.INFO)
    
try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, port=myport)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

start = " "
end = " "
def get_secret_surety():
    secret_name = os.environ['surety']
    region_name = os.environ['AWS_REGION']

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e

    # Decrypts secret using the associated KMS key.
    secret = get_secret_value_response['SecretString']
    jsonStr = json.loads(secret)
    start = jsonStr["start"]
    currVal = jsonStr["current"]
    incrementBy = jsonStr['increment']
    end =  jsonStr['end']
    newVal=int(currVal)+int(incrementBy)
    if int(newVal) >= int(start) and int(newVal)<=int(end): 

        client.update_secret(SecretId=secret_name,SecretString=json.dumps({"type":"Surety", "start":"8050001", "current":str(newVal), "end":"8060000" , "increment":"1"}))
        
        return {"start":str(start),"end":str(end),"current":str(newVal)}
    else:
        return 'NA'

def get_secret_arden():
    secret_name = os.environ["arden"]
    region_name = os.environ['AWS_REGION']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e

    # Decrypts secret using the associated KMS key.
    secret = get_secret_value_response['SecretString']

    jsonStr = json.loads(secret)
    currVal = jsonStr["current"]
    start = jsonStr['start']
    end  = jsonStr['end']
    incrementBy = jsonStr['increment']
    newVal=int(currVal)+int(incrementBy)
    if int(newVal) >= int(start) and int(newVal)<=int(end):
        client.update_secret(SecretId=secret_name,SecretString=json.dumps({"type":"Arden", "start":"8000000", "current":str(newVal),"end":"8050000" , "increment":"1"}))
        return {"start":str(start),"end":str(end),"current":str(newVal)}
    else:
        return 'NA'

def get_secret_policy():
    secret_name = os.environ['policy']
    region_name = os.environ['AWS_REGION']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )

    except ClientError as e:
        
        raise e

    # Decrypts secret using the associated KMS key.
    secret = get_secret_value_response['SecretString']
    
    
    jsonStr = json.loads(secret)
    #print(type(jsonStr))
    currVal = jsonStr["current"]
    incrementBy = jsonStr['increment']
    newVal=int(currVal)+int(incrementBy)
    
    surety = get_secret_surety()
    startSurety = surety["start"]
    endSurety = surety["end"]

    arden = get_secret_arden()
    startArden = arden['start']
    endArden = arden['end']
    
    #testing valuses
    print(startArden)
    print(endArden)
    print(startSurety)
    print(endSurety)

    
    if startArden < startSurety and endArden + incrementBy == startSurety:
    
        if newVal == startArden:
            newVal = endSurety + incrementBy

    elif startSurety < startArden and endSurety + incrementBy == startArden:
        if newVal == startSurety:
            newVal = endArden + incrementBy
       
  
    else:
        if startSurety < startArden:
            if newVal == startSurety:
                newVal = endSurety + incrementBy
                

                
            elif newVal == startArden:
                newVal = endArden + incrementBy
                
                   
        
        elif startArden < startSurety:
            if newVal == startSurety:
                newVal = endSurety + incrementBy
                
              
                
            elif newVal == startArden:
                newVal = endArden + incrementBy
                
                
    client.update_secret(SecretId=secret_name,SecretString=json.dumps({"type":"Policy", "start":"4000000", "current":str(newVal), "increment":"1"}))
    return {"start":str(start),"end":str(end),"current":str(newVal)}        
    
def get_secret_account():
    secret_name = os.environ['account']
    region_name = os.environ['AWS_REGION']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        
        raise e

    # Decrypts secret using the associated KMS key.
    secret = get_secret_value_response['SecretString']
    jsonStr = json.loads(secret)
    currVal = jsonStr["current"]
    incrementBy = jsonStr['increment']
    newVal=int(currVal)+int(incrementBy)

    
    client.update_secret(SecretId=secret_name,SecretString=json.dumps({"type":"Account", "start":"30000000", "current":str(newVal), "increment":"1"}))
    return {"current":str(newVal)}
    

GET_PATH = "GET"
POST_PATH = "POST"
    
def lambda_handler(event, context): 

   
    if event['httpMethod'] == POST_PATH:
    
        decodedBody = json.loads(event['body'])
        
        start_time = ""
        val=""
        Message=""
        
        if decodedBody["AppName"] == "GuideWire":
            
            if decodedBody["No"] == "Account":
                
                start_time = time.perf_counter()
                val=get_secret_account()
                Message= "Account number for GuideWire is " + val['current']
                
            elif decodedBody["No"] == "Policy":
                
                start_time = time.perf_counter()
                val=get_secret_policy()
                print(val)
                Message= "Policy number for GuideWire is " + val['current']
                
            else :
                
                return {
                    'body': json.dumps("message: Quote is blocked for GuideWire") 
                }
                
        elif decodedBody["AppName"] == "Surety":
            
            if decodedBody["No"] == "Account":
                
                start_time = time.perf_counter()
                val=get_secret_surety()
                Message= "Account number for Surety is " + val['current']
                
            elif decodedBody["No"] == "Policy":
                
                return {
                    'body': json.dumps("Policy number is blocked for Surety.") 
                }
                
            else :
                
                return {
                    'body': json.dumps("message: Quote is blocked for Surety") 
                }
                
        elif decodedBody["AppName"] == "Arden":
            
            if decodedBody["No"] == "Account":
                
                start_time = time.perf_counter()
                val=get_secret_arden()
                Message= "Account number For Arden is " + val['current']
                
            elif decodedBody["No"] == "Policy":
                
                return {
                    'body': json.dumps("Policy number is blocked for Arden") 
                }
                
            else :
                return {
                    'body': json.dumps("message: Quote is blocked for Arden") 
                }
                
        else :
            return {
                'body': json.dumps("message: Cannot generate any number for APS") 
            }
      
        
        with conn.cursor() as cur:
            ##cur.execute('CREATE TABLE IDs (Id int, Details varchar(255))')
            cur.execute('insert into IDs (Id, Details) values("'+str(val['current'])+'", "'+Message+'")')
            current_time = time.perf_counter() - start_time
            print(f"request time is : {current_time} sec")
        conn.commit()
       
        return {
            'body': json.dumps(Message) 
        }
        
    elif event['httpMethod'] == GET_PATH:
    
        with conn.cursor() as cur:
            qry = "select * from IDs"
            cur.execute(qry)
            rec = cur.fetchall()
            body = rec
            
        return {
            'statusCode': 200,
            'body': json.dumps(body) 
        }