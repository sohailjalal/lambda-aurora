import json
import sys
import logging
import pymysql
import os
import boto3
from botocore.exceptions import ClientError

REGION = os.environ['AWS_REGION']
rds_host = os.environ['host']
name = os.environ['username']
password = os.environ['password']
db_name = os.environ['database']
myport = 3306   
lambdafunction = os.environ['lambda_arn']

logger = logging.getLogger()
logger.setLevel(logging.INFO)
    
try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, port=myport)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

GET_PATH = "GET"
POST_PATH = "POST"
    
def lambda_handler(event, context): 
   
    if event['httpMethod'] == POST_PATH:
        item_count = 0
        decodedBody = json.loads(event['body'])
        
        invokeLam = boto3.client("lambda",region_name=REGION)
        payload = {"No": decodedBody['No'],"App":decodedBody["AppName"]}
        print(payload)
        resp = invokeLam.invoke(FunctionName=lambdafunction, 
            InvocationType="RequestResponse", Payload=json.dumps(payload))
        t = json.loads(resp['Payload'].read())
        print(t)
        
        val=""
        Message=""
        
        if decodedBody["AppName"] == "GuideWire":
            
            if decodedBody["No"] == "Account":
                
                # return {'Account No For GuideWire is': json.dumps(json.loads(t["value"]))}
                val = t["value"]
                Message= "Account number for GuideWire is " + val
                
            elif decodedBody["No"] == "Policy":
                
                # return {'Policy No For GuideWire is': json.dumps(json.loads(t["value"]))}
                val = t["value"]
                print(val)
                Message= "Policy number for GuideWire is " + val
                
            else :
                
                return {
                    'body': json.dumps("message: Quote is blocked for GuideWire") 
                }
                
        elif decodedBody["AppName"] == "Surety":
            
            if decodedBody["No"] == "Account":
                
                # return {'Account No For Surety is': json.dumps(json.loads(t["value"]))}
                val = t["value"]
                Message= "Account number for Surety is " + val
                
            elif decodedBody["No"] == "Policy":
                
                return {
                    'body': json.dumps("Policy number is blocked for Surety.") 
                }
                
            else :
                
                return {
                    'body': json.dumps("message: Quote is blocked for Surety") 
                }
                
        elif decodedBody["AppName"] == "Arden":
            
            if decodedBody["No"] == "Account":
                
                # return {'Account No For Arden is': json.dumps(json.loads(t["value"]))}
                val = t["value"]
                Message= "Account number For Arden is " + val
                
            elif decodedBody["No"] == "Policy":
                
                return {
                    'body': json.dumps("Policy number is blocked for Arden") 
                }
                
            else :
                return {
                    'body': json.dumps("message: Quote is blocked for Arden") 
                }
                
        else :
            return {
                'body': json.dumps("message: Cannot generate any number for APS") 
            }
      
        
        with conn.cursor() as cur:
            ##cur.execute('CREATE TABLE IDs (Id int, Details varchar(255))')
            cur.execute('insert into IDs (Id, Details) values("'+val+'", "'+Message+'")')
        conn.commit()
       
        return str(Message)
        
    elif event['httpMethod'] == GET_PATH:
    
        with conn.cursor() as cur:
            qry = "select * from IDs"
            cur.execute(qry)
            rec = cur.fetchall()
            body = rec
            
        return {
            'statusCode': 200,
            'body': json.dumps(body) 
        }