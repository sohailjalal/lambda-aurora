import json
import os
import boto3
from botocore.exceptions import ClientError

start = " "
end = " "
def get_secret_surety():
    secret_name = os.environ['surety']
    region_name = os.environ['AWS_REGION']

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e

    # Decrypts secret using the associated KMS key.
    secret = get_secret_value_response['SecretString']
    jsonStr = json.loads(secret)
    start = jsonStr["start"]
    currVal = jsonStr["current"]
    incrementBy = jsonStr['increment']
    end =  jsonStr['end']
    newVal=int(currVal)+int(incrementBy)
    if int(newVal) >= int(start) and int(newVal)<=int(end): 

        client.update_secret(SecretId=secret_name,SecretString=json.dumps({"type":"Surety", "start":"8050001", "current":str(newVal), "end":"8060000" , "increment":"1"}))
        
        return {"start":str(start),"end":str(end),"current":str(newVal)}
    else:
        return 'NA'

def get_secret_arden():
    secret_name = os.environ['arden']
    region_name = os.environ['AWS_REGION']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e

    # Decrypts secret using the associated KMS key.
    secret = get_secret_value_response['SecretString']

    jsonStr = json.loads(secret)
    currVal = jsonStr["current"]
    start = jsonStr['start']
    end  = jsonStr['end']
    incrementBy = jsonStr['increment']
    newVal=int(currVal)+int(incrementBy)
    if int(newVal) >= int(start) and int(newVal)<=int(end):
        client.update_secret(SecretId=secret_name,SecretString=json.dumps({"type":"Arden", "start":"8000000", "current":str(newVal),"end":"8050000" , "increment":"1"}))
        return {"start":str(start),"end":str(end),"current":str(newVal)}
    else:
        return 'NA'

def get_secret_policy():
    secret_name = os.environ['policy']
    region_name = os.environ['AWS_REGION']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )

    except ClientError as e:
        
        raise e

    # Decrypts secret using the associated KMS key.
    secret = get_secret_value_response['SecretString']
    
    
    jsonStr = json.loads(secret)
    #print(type(jsonStr))
    currVal = jsonStr["current"]
    incrementBy = jsonStr['increment']
    newVal=int(currVal)+int(incrementBy)
    
    surety = get_secret_surety()
    startSurety = surety["start"]
    endSurety = surety["end"]

    arden = get_secret_arden()
    startArden = arden['start']
    endArden = arden['end']
    
    #testing valuses
    print(startArden)
    print(endArden)
    print(startSurety)
    print(endSurety)

    
    if startArden < startSurety and endArden + incrementBy == startSurety:
    
        if newVal == startArden:
            newVal = endSurety + incrementBy

    elif startSurety < startArden and endSurety + incrementBy == startArden:
        if newVal == startSurety:
            newVal = endArden + incrementBy
       
  
    else:
        if startSurety < startArden:
            if newVal == startSurety:
                newVal = endSurety + incrementBy
                

                
            elif newVal == startArden:
                newVal = endArden + incrementBy
                
                   
        
        elif startArden < startSurety:
            if newVal == startSurety:
                newVal = endSurety + incrementBy
                
              
                
            elif newVal == startArden:
                newVal = endArden + incrementBy
                
                
    client.update_secret(SecretId=secret_name,SecretString=json.dumps({"type":"Policy", "start":"4000000", "current":str(newVal), "increment":"1"}))
    return {"start":str(start),"end":str(end),"current":str(newVal)}        
    

def get_secret_account():
    secret_name = os.environ['account']
    region_name = os.environ['AWS_REGION']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        
        raise e

    # Decrypts secret using the associated KMS key.
    secret = get_secret_value_response['SecretString']
    jsonStr = json.loads(secret)
    currVal = jsonStr["current"]
    incrementBy = jsonStr['increment']
    newVal=int(currVal)+int(incrementBy)

    
    client.update_secret(SecretId=secret_name,SecretString=json.dumps({"type":"Account", "start":"30000000", "current":str(newVal), "increment":"1"}))
    return {"current":str(newVal)}

def lambda_handler(event, context):
    No = event['No']
    App = event['App']
    retVal=''
    if App == 'GuideWire':
        if No == "Account":
            retVal = get_secret_account()
        elif No == "Policy":
            retVal = get_secret_policy()
    elif App == 'Surety':
        if No == 'Account':
           retVal =  get_secret_surety()
        elif No == 'Policy':
            retVal = "NA"
    elif App == 'Arden':
        if No == 'Account':
            retVal =  get_secret_arden()
        elif No == 'Policy':
            retVal = "NA"
    print(retVal)
    return {"value": retVal['current']}