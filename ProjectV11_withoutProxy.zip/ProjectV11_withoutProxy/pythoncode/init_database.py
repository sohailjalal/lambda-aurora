import json
import sys
import logging
import pymysql
import os
import time
import datetime
import asyncio

# getting crediential from variable.tf file
REGION = os.environ['AWS_REGION']
rds_host = os.environ['host']
name = os.environ['username']
password = os.environ['password']
db_name = os.environ['database']
myport = 3306   

logger = logging.getLogger()
logger.setLevel(logging.INFO)
    
# This try block is Making a connection with RDS
try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, port=myport)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

def Create_GuideWire_Account_Table():
    try:
        with conn.cursor() as cur:
            table_name = "GuideWireAccountIDS"
            start_autoincr = 30000000

            cur.execute(f'CREATE TABLE {table_name} (Id INT UNSIGNED NOT NULL AUTO_INCREMENT, AppName varchar(255), Type varchar(255), Date varchar(255), Time varchar(255), User varchar(255), PRIMARY KEY (Id))AUTO_INCREMENT = {start_autoincr};')

        conn.commit()
        
    except Exception as e:
        print("ERROR: Unexpected error.."+ str(e))

def Create_GuideWire_Policy_Table():
    try:
        with conn.cursor() as cur:
            table_name = "GuideWirePolicyIDS"
            start_autoincr = 4000000

            cur.execute(f'CREATE TABLE {table_name} (Id INT UNSIGNED NOT NULL AUTO_INCREMENT, AppName varchar(255), Type varchar(255), Date varchar(255), Time varchar(255), User varchar(255), PRIMARY KEY (Id))AUTO_INCREMENT = {start_autoincr};')

        conn.commit()
        
    except Exception as e:
        print("ERROR: Unexpected error.."+ str(e))   

def Create_Arden_Account_Table():
    try:
        with conn.cursor() as cur:
            table_name = "ArdenAccountIDS"
            start_autoincr = 8000000

            cur.execute(f'CREATE TABLE {table_name} (Id INT UNSIGNED NOT NULL AUTO_INCREMENT, AppName varchar(255), Type varchar(255), Date varchar(255), Time varchar(255), User varchar(255), PRIMARY KEY (Id))AUTO_INCREMENT = {start_autoincr};')

        conn.commit()
        
    except Exception as e:
        print("ERROR: Unexpected error.."+ str(e))

def Create_Surety_Account_Table():
    try:
        with conn.cursor() as cur:
            table_name = "SuretyAccountIDS"
            start_autoincr = 8050001

            cur.execute(f'CREATE TABLE {table_name} (Id INT UNSIGNED NOT NULL AUTO_INCREMENT, AppName varchar(255), Type varchar(255), Date varchar(255), Time varchar(255), User varchar(255), PRIMARY KEY (Id))AUTO_INCREMENT = {start_autoincr};')

        conn.commit()
        
    except Exception as e:
        print("ERROR: Unexpected error.."+ str(e))   

                    
def generateSequenceTable():

    try:
            
        with conn.cursor() as cur:
            table_name = 'sequence'
            
            cur.execute(f'CREATE TABLE {table_name} (Id INT UNSIGNED NOT NULL AUTO_INCREMENT,'+ 
            'AppName varchar(50), StartId INT, EndId INT, Type varchar(50), CurrentValue INT, PRIMARY KEY (Id));')
                                
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("GuideWire", "30000000", "Null", "Account", "Null")')
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("GuideWire", "4000000", "Null", "Policy", "Null")')
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("GuideWire", "Null", "Null", "Quote", "Null")')
        
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("Arden", "8000000", "8050000", "Account", "Null")')
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("Arden", "Null", "Null", "Policy", "Null")')
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("Arden", "Null", "Null", "Quote", "Null")')
        
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("Surety", "8050001", "8060000", "Account", "Null")')
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("Surety", "Null", "Null", "Policy", "Null")')
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("Surety", "Null", "Null", "Quote", "Null")')
        
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("APS", "Null", "Null", "Account", "Null")')
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("APS", "Null", "Null", "Policy", "Null")')
            cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
            'values("APS", "Null", "Null", "Quote", "Null")')
    
            qry = f"select * from {table_name}"
            cur.execute(qry)
            rec = cur.fetchall()
            body = rec
                    
        conn.commit()
        return {
            'statusCode': 200,
            'body': json.dumps(body) 
        }

    except Exception as e:
        print("ERROR: "+ str(e))


    
def lambda_handler(event, context):
    Create_GuideWire_Account_Table()
    Create_GuideWire_Policy_Table()
    Create_Arden_Account_Table()
    Create_Surety_Account_Table()
    sequenceTable = generateSequenceTable()
    return {"body": sequenceTable}  