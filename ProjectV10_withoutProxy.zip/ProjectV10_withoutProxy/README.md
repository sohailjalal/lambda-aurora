#### How to setup ID_Generator

Prerequisites for this project
-------------------------------
Installation of ID Generator requires following permissions and resources:
1) Public & Private Subnets
2) Security Group
3) Virtual Private Cloud
4) NAT Gateway
5) RDS Aurora Serverless
6) RDS Proxy
7) Key Management Service (kms)
8) Secrets Manager
9) Lambda Function

=> First download project from github and extract it. Open project in any editor(VS Code, Notepad++ etc).
=> Select a secrets.auto.tfvars file and change the Account Id and Region according to your AWS Account Id and Region.
=> Download and Install aws-cli tool and configure it in your system.
=> Open command prompt (cmd) and navigate to ID Generator directory.
=> Run "terraform init" command to initialize terraform in the project. 
=> Run "terraform plan" command to plan the recources.
=> Run "terraform apply" command to create the recources in aws.

=> After "terraform apply" command completes, copy the Lambda function url and use it to call GET method through browser or Postman.
=> In the POST method of Lambda function, send parameters in JSON format.

   Details of REST API parameters:
    AppName: This is the application name e.g. GuideWire, Surety, Arden and APS.
    Type: This is Id Type e.g. Account, Policy and Quote.
    User: This contains user details e.g. email address or any other system info

    Example:
      curl -H "Content-Type: application/json" -X POST -d "{\"AppName\":\"Surety\",\"Type\":\"Account\",\"User\":\"johndoe12345@gmail.com\"}" "<Lambda function`s url>"

#### Schema for RDS
Lambda function creates following 5 tables in the RDS database:
1) GuideWireAccountIDS
2) GuideWirePolicyIDS
3) SuretyAccountIDS
4) ArdenAccountIDS
5) Sequence


#### Table for sequence

=> Columns in the sequence table are ( Id, AppName, Type, StartId, EndId and CurrentValue ) and it is used to store 
   start, end and the latest Id value of GuideWireAccountIDS, GuideWirePolicyIDS, SuretyAccountIDS and ArdenAccountIDS tables.

#### Table for GuideWireAccountIDS

=> Columns in the GuideWireAccountIDS table are ( Id, AppName, Type, Date, Time and User ) and it is used to generate a 
   new Id and save application name, type of id, current date, time and user information in the GuideWireAccountIDS table.

#### Table for GuideWirePolicyIDS

=> Columns in the GuideWirePolicyIDS table are ( Id, AppName, Type, Date, Time and User ) and it is used to generate a 
   new Id and save application name, type of id, current date, time and user information in the GuideWirePolicyIDS table.

#### Table for SuretyAccountIDS

=> Columns in the SuretyAccountIDS table are ( Id, AppName, Type, Date, Time and User ) and it is used to generate a 
   new Id and save application name, type of id, current date, time and user information in the SuretyAccountIDS table.

#### Table for ArdenAccountIDS

=> Columns in the ArdenAccountIDS table are ( Id, AppName, Type, Date, Time and User ) and it is used to generate a 
   new Id and save application name, type of id, current date, time and user information in the ArdenAccountIDS table.