import json
import sys
import logging
import pymysql
import os
import boto3
from botocore.exceptions import ClientError
import time
import threading
import datetime
import asyncio

    # getting crediential from variable.tf file
REGION = os.environ['AWS_REGION']
rds_host = os.environ['host']
name = os.environ['username']
password = os.environ['password']
db_name = os.environ['database']
myport = 3306   

logger = logging.getLogger()
logger.setLevel(logging.INFO)
    
    # Make a connection with RDS
try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, port=myport)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

start = " "
end = " "

# This method generatea Id for Application
async def idGenerate(tableName, start):
    try:
        now = datetime.datetime.utcnow()
        latestId = ""
        with conn.cursor() as cur:
            table_name = tableName
            startNo = start
            _SQL = """SHOW TABLES"""
            cur.execute(_SQL) # check if table exists in RDS 
            results = cur.fetchall()
                    
            results_list = [item[0] for item in results] # Convert tables to array list

            if table_name in results_list: # if table exists in RDS, this block is executed and inserts values into in database

                date = str(now.strftime('%Y-%m-%d %H:%M:%S'))
                cur.execute(f'insert into {table_name} (Details) values( "'+date+'")')
                    
                latestId = cur.lastrowid
                        
            else: # if table does not exist in RDS, then this block creates a new table in RDS and then insert data in database
                cur.execute(f'CREATE TABLE {table_name} (Id INT UNSIGNED NOT NULL AUTO_INCREMENT, Details varchar(255), PRIMARY KEY (Id))AUTO_INCREMENT = {startNo};')
                        
                date = str(now.strftime('%Y-%m-%d %H:%M:%S'))
                cur.execute(f'insert into {table_name} (Details) values("'+date+'")')
                    
                latestId = cur.lastrowid

        conn.commit()
        return {"current":str(latestId)}
            
        
    except Exception as e:
        print("ERROR: Unexpected error.."+ str(e))   
    

GET_PATH = "GET"
POST_PATH = "POST"

# Handle API Request
async def invoke_lambda(event): 
    if event['httpMethod'] == POST_PATH: # check API Gateway Request
        decodedBody = json.loads(event['body']) # get body response

        val=""
        Message=""
        
        if decodedBody["AppName"] == "GuideWire": 
            if decodedBody["Type"] == "Account":
                try:
                    tbl_name_for_idgenerate = "guidewireAccountIDs"
                    tbl_name_for_sequence = "sequence"
                    
                    appname = decodedBody["AppName"]
                    type = decodedBody["Type"]
                    
                    startId = ""
                    
                    with conn.cursor() as cur: # get seed data from database
                                
                        records = cur.execute(f"SELECT * FROM {tbl_name_for_sequence} WHERE AppName= '{appname}' AND Type= '{type}'")
                        records = cur.fetchall()
                        
                        for row in records:
                            startId = row[2] # get startId from RDS
                    conn.commit()
                    
                    val = await idGenerate(tbl_name_for_idgenerate, startId)  # method for generate Id
                    latestId = val['current'] # latest id from RDS
                    with conn.cursor() as cur: # Update data in RDS
                        cur.execute(f"UPDATE {tbl_name_for_sequence} SET CurrentValue = {str(latestId)} WHERE AppName= '{appname}' AND Type= '{type}'")
                    conn.commit()

                    
                    Message= "Account number for GuideWire is " + val['current'] # return Message
    
                except Exception as e:
                    print("ERROR: Unexpected error.."+ str(e))
                
            elif decodedBody["Type"] == "Policy":
                
                try:
                    
                    appname = decodedBody["AppName"]
                    type = decodedBody["Type"]

                    tbl_name_for_idgenerate = "guidewirePolicyIDs"
                    tbl_name_for_sequence = "sequence"
                    
                    startId = ""
                    
                    with conn.cursor() as cur:
                                
                        records1 = cur.execute(f"SELECT * FROM {tbl_name_for_sequence} WHERE AppName= '{appname}' AND Type= '{type}'")
                        records1 = cur.fetchall()
                        
                        for row in records1:
                            startId = row[2]
                                    
                    conn.commit()

                    
                    startSurety = ""
                    endSurety = ""
                    
                    with conn.cursor() as cur:
                                
                        records2 = cur.execute(f"SELECT * FROM {tbl_name_for_sequence} WHERE AppName= 'Surety' AND Type= 'Account'")
                        records2 = cur.fetchall()
                        
                        for row in records2:
                            startSurety = row[2]
                            endSurety = row[3]
                                    
                    conn.commit()

                    startArden = ""
                    endArden =""
                    
                    with conn.cursor() as cur:
                                
                        records3 = cur.execute(f"SELECT * FROM {tbl_name_for_sequence} WHERE AppName= 'Arden' AND Type= 'Account'")
                        records3 = cur.fetchall()
                        
                        for row in records3:
                            startArden = row[2]
                            endArden = row[3]
                                    
                    conn.commit()
                    

                    
                    val = await idGenerate(tbl_name_for_idgenerate, startId)

                    
                    latestId = val['current']

                    ''' Apply condition if the policy value is 7 digits and arden, surity values also laying in 7 digit. So we check whether the
                        arden or surity values laying in between policy values if so we can generate new values after check which has greater end value.'''

                    if int(startArden) < int(startSurety) and int(endArden) + 1 == int(startSurety):
    
                        if int(latestId) == int(startArden):
                            latestId = int(endSurety) + 1

                    elif int(startSurety) < int(startArden) and int(endSurety) + 1 == int(startArden):
                        if int(latestId) == int(startSurety):
                            latestId = int(endArden) + 1
                    
                
                    else:
                        if int(startSurety) < int(startArden):
                            if int(latestId) == int(startSurety):
                                latestId = int(endSurety) + 1
                                

                                
                            elif int(latestId) == int(startArden):
                                latestId = int(endArden) + 1
                                
                                
                        
                        elif int(startArden) < int(startSurety):
                            if int(latestId) == int(startSurety):
                                latestId = int(endSurety) + 1
                                    
                            elif int(latestId) == int(startArden):
                                latestId = int(endArden) + 1
                    
                    with conn.cursor() as cur:
                                
                        cur.execute(f"UPDATE {tbl_name_for_sequence} SET CurrentValue = {str(latestId)} WHERE AppName= '{appname}' AND Type= '{type}'")
                                    
                    conn.commit()

                    Message= "Policy number for GuideWire is " + val['current']
    
                except Exception as e:
                    print("ERROR: Unexpected error.."+ str(e))
                
            else :
                return {
                    'body': json.dumps("message: Quote is blocked for GuideWire") 
                }
                
        elif decodedBody["AppName"] == "Surety":
            
            if decodedBody["Type"] == "Account":
                
                try:

                    tbl_name_for_idgenerate = "suretyAccountIDs"
                    tbl_name_for_sequence = "sequence"
                    
                    appname = decodedBody["AppName"]
                    type = decodedBody["Type"]
                    
                    startId = ""
                    endId= ""
                    
                    with conn.cursor() as cur:
                                
                        records = cur.execute(f"SELECT * FROM {tbl_name_for_sequence} WHERE AppName= '{appname}' AND Type= '{type}'")
                        records = cur.fetchall()
                        
                        for row in records:
                            startId = row[2]
                            endId = row[3]
                                    
                    conn.commit()
                    
                    
                    val = await idGenerate(tbl_name_for_idgenerate, startId)

                    
                    latestId = val['current']



                    if(int(latestId) >=int(startId) and int(latestId) <= int(endId)):

                        with conn.cursor() as cur:
                                
                            cur.execute(f"UPDATE {tbl_name_for_sequence} SET CurrentValue = {str(latestId)} WHERE AppName= '{appname}' AND Type= '{type}'")
                                    
                        conn.commit()
                    else:
                        return {
                            'body': json.dumps("Account number is blocked for Surety.") 
                        }

                    Message= "Account number for Surety is " + val['current']
                    
    
                except Exception as e:
                    print("ERROR: Unexpected error.."+ str(e))
                
            elif decodedBody["Type"] == "Policy":
                
                return {
                    'body': json.dumps("Policy number is blocked for Surety.") 
                }
                
            else :
                
                return {
                    'body': json.dumps("message: Quote is blocked for Surety") 
                }
                
        elif decodedBody["AppName"] == "Arden":
            
            if decodedBody["Type"] == "Account":
                
                try:

                    tbl_name_for_idgenerate = "ardenAccountIDs"
                    tbl_name_for_sequence = "sequence"
                    
                    appname = decodedBody["AppName"]
                    type = decodedBody["Type"]
                    
                    startId = ""
                    endId= ""
                    
                    with conn.cursor() as cur:
                                
                        records = cur.execute(f"SELECT * FROM {tbl_name_for_sequence} WHERE AppName= '{appname}' AND Type= '{type}'")
                        records = cur.fetchall()
                        
                        for row in records:
                            startId = row[2]
                            endId = row[3]
                                    
                    conn.commit()
                    
                    
                    val = await idGenerate(tbl_name_for_idgenerate, startId)

                    
                    latestId = val['current']
                    
                    

                    if(int(latestId) >= int(startId) and int(latestId) <= int(endId)):

                        
                        with conn.cursor() as cur:
                                
                            cur.execute(f"UPDATE {tbl_name_for_sequence} SET CurrentValue = {str(latestId)} WHERE AppName= '{appname}' AND Type= '{type}'")
                                    
                        conn.commit()
                    else:
                        return {
                            'body': json.dumps("Account number is blocked for Arden.") 
                        }

                    Message= "Account number For Arden is " + val['current']
                    
    
                except Exception as e:
                    print("ERROR: Unexpected error.."+ str(e))
                
            elif decodedBody["Type"] == "Policy":
                
                return {
                    'body': json.dumps("Policy number is blocked for Arden") 
                }
                
            else :
                return {
                    'body': json.dumps("message: Quote is blocked for Arden") 
                }
                
        else :
            return {
                'body': json.dumps("message: Cannot generate any number for APS") 
            }

        
        
        return {
            'body': json.dumps(Message) 
        }

        
    # Handle API GET Request
    elif event['httpMethod'] == GET_PATH:

        try:
            
            with conn.cursor() as cur:
                table_name = 'sequence'
                _SQL = """SHOW TABLES"""
                cur.execute(_SQL)   # check the table in RDS
                results = cur.fetchall()

                results_list = [item[0] for item in results] # Conversion to list of str
                
                if table_name in results_list: # if table is already exist in RDS this block is execute and insert data in database

                    qry = f"select * from {table_name}"
                    cur.execute(qry)
                    rec = cur.fetchall()
                    body = rec

                else:
                    ###if table is not exist in RDS this block is create a new table in RDS and then insert data in database
                    cur.execute(f'CREATE TABLE {table_name} (Id INT UNSIGNED NOT NULL AUTO_INCREMENT,'+ 
                    'AppName varchar(50), StartId INT, EndId INT, Type varchar(50), CurrentValue INT, PRIMARY KEY (Id));')
                            
                    cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
                    'values("GuideWire", "30000000", "Null", "Account", "Null")')
                    cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
                    'values("GuideWire", "4000000", "Null", "Policy", "Null")')
    
                    cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
                    'values("Arden", "8000000", "8050000", "Account", "Null")')
                    cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
                    'values("Arden", "Null", "Null", "Policy", "Null")')
    
                    cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
                    'values("Surety", "8050001", "8060000", "Account", "Null")')
                    cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
                    'values("Surety", "Null", "Null", "Policy", "Null")')
    
                    cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
                    'values("APS", "Null", "Null", "Account", "Null")')
                    cur.execute(f'insert into {table_name} (AppName, StartId, EndId, Type, CurrentValue) '+
                    'values("APS", "Null", "Null", "Policy", "Null")')
    
                    qry = f"select * from {table_name}"
                    cur.execute(qry)
                    rec = cur.fetchall()
                    body = rec
                    
            conn.commit()
            return {
                'statusCode': 200,
                'body': json.dumps(body) 
            }

        except Exception as e:
            print("ERROR: "+ str(e))

    
def lambda_handler(event, context):
    
    start_time = time.perf_counter()
    
    res = asyncio.run(invoke_lambda(event))
    
    stop_time = time.perf_counter()
    elapse_time = stop_time - start_time
    print(f"requcurest time is : {elapse_time*1000} milliseconds")
    
    return res   