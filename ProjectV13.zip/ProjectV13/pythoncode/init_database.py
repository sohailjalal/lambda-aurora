import json
import sys
import logging
import pymysql
import os
import asyncio

# getting credientials from variable.tf file
REGION = os.environ['AWS_REGION']
rds_host = os.environ['host']
name = os.environ['username']
password = os.environ['password']
db_name = os.environ['database']
myport = 3306 

startRange = os.environ['start_range']
endRange = os.environ['end_range']

logger = logging.getLogger()
logger.setLevel(logging.INFO)
    
# This try block makes a connection with RDS
try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, port=myport)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

async def Create_Range_Table():
    try:
        
        with conn.cursor() as cur:
            table_name = "SequenceRange"

            cur.execute(f'CREATE TABLE {table_name} (Id INT UNSIGNED NOT NULL AUTO_INCREMENT, StartRange int, EndRange int, Status varchar(255), PRIMARY KEY (Id))AUTO_INCREMENT = {1};')
            cur.execute(f"INSERT INTO {table_name} (StartRange, EndRange, Status) values('{startRange}', '{endRange}', 'True')")

        conn.commit()
        
    except Exception as e:
        print("ERROR: Unexpected error.."+ str(e))

async def Create_Sequence_Ids_Table():
    try:
        with conn.cursor() as cur:
            table_name = "SequenceIds"
            GWPolicyRange = cur.execute("SELECT * FROM SequenceRange WHERE Status= 'True' ")
            GWPolicyRange = cur.fetchall()
                        
            for row in GWPolicyRange:
                startId = row[1] # get startId from RDS
            start_autoincr = startId

            cur.execute(f'CREATE TABLE {table_name} (Id INT UNSIGNED NOT NULL AUTO_INCREMENT, AppName varchar(255), Type varchar(255), Date varchar(255), Time varchar(255), User varchar(255), PRIMARY KEY (Id))AUTO_INCREMENT = {start_autoincr};')

        conn.commit()
        
    except Exception as e:
        print("ERROR: Unexpected error.."+ str(e))   
 

async def executeMyQuery():
    try:
        await Create_Range_Table()
        await Create_Sequence_Ids_Table()

    except Exception as e:
        print("ERROR: Unexpected error.."+ str(e))
                   
def lambda_handler(event, context):
    try:
        asyncio.run(executeMyQuery())
    except Exception as e:
        print("ERROR: Unexpected error.."+ str(e))
    return {"body": "Tables are successfully created"}  